using System;
using System.Collections.Generic;
using System.Linq;



namespace AeroCalcCore.FlightPerformanceEngine
{


    /// <summary>
    /// Classe de dimension 3 du package 'Calculateur de performances de vol'
    /// Enregistre les caract�ristiques d'un ensemble coh�rent de s�rie de performances de vol
    /// Par contraction, une layer de s�ries de points de performances de vol s'appelle 'layer de performance'
    /// </summary>
    public class PerfLayer : IComparable<PerfLayer>
    {

        // PROPERTIES ///////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// Cl� de la layer dans une base de donn�e
        /// </summary>
        public long dataBaseKey
        {
            get;
            set;
        }

        /// <summary>
        /// Nombre de s�ries dans la layer
        /// </summary>
        public int count
        {
            get
            {
                return perfSerieList.Count;
            }
        }

        /// <summary>
        /// Nom de la Layer (nom des r�sultats des pr�dictions r�alis�es avec cette Layer)
        /// </summary>
        public String outputName
        {
            get;
            private set;
        }

        /// <summary>
        /// Unit� de mesure de la pr�diction
        /// </summary>
        public int outputUnitCode
        {
            get;
            private set;
        }

        /// <summary>
        /// Valeur du facteur associ� � la Layer
        /// </summary>
        /// <remarks>Dim 3</remarks>
        public double factorValue
        {
            get;
            private set;
        }

        /// <summary>
        /// Nom de la deuxi�me dimension (s�ries de performanes)
        /// </summary>
        /// <remarks>Dim 2</remarks>
        public String serieFactorName
        {
            get;
            private set;
        }

        /// <summary>
        /// Unit� de mesure de la deuxi�me dimension, utilis�e pour les calculs de pr�diction
        /// </summary>
        public int serieFactorUnitCode
        {
            get;
            private set;
        }

        /// <summary>
        /// Nom de la premi�re dimension (points de performances)
        /// </summary>
        /// <remarks>Dim 1</remarks>
        public String pointFactorName
        {
            get;
            private set;
        }

        /// <summary>
        /// Unit� de mesure de la premi�re dimension, utilis�e pour les calculs de pr�diction
        /// </summary>
        public int pointFactorUnitCode
        {
            get;
            private set;
        }

        /// <summary>
        /// Indique si le range de la s�rie a �t� d�fini
        /// </summary>
        public bool ranged
        {
            get;
            private set;
        }

        /*
        /// <summary>
        /// Etat de s�lection de la Layer. La s�lection permet de ne prendre en compte
        /// que certaines Layer pour les calculs de pr�diction
        /// </summary>
        public bool selected
        {
            get;
            set;
        }
        */

        /// <summary>
        /// Etat 'breakpoint' de la layer de points de performance (rupture de lin�arit�)
        /// </summary>
        public bool isBreak
        {
            get;
            private set;
        }



        // FIELDS ///////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// Borne inf�rieure du domaine de calcul
        /// </summary>
        /// <remarks>Dim pp2</remarks>
        double startRange;

        /// <summary>
        /// Nature de la borne inf�rieure du domaine de calcul
        /// </summary>
        int startRangeType;

        /// <summary>
        /// Borne sup�rieure du domaine de calcul
        /// </summary>
        /// <remarks>Dim pp2</remarks>
        double endRange;

        /// <summary>
        /// Nature de la borne sup�rieure du domaine de calcul
        /// </summary>
        int endRangeType;

        /// <summary>
        /// Liste g�n�rique utilis�e pour ordonner les s�ries de performances
        /// </summary>
        List<PerfSerie> perfSerieList;


        // Constructor(s) ///////////////////////////////////////////////////////////////////////////////////


        /// <summary>
        /// Construction d'une Layer vide de toute s�rie et non param�tr�e
        /// </summary>
        public PerfLayer()
        {
            perfSerieList = new List<PerfSerie>();
        }


        /// <summary>
        /// Construction par clonage d'une Layer de s�ries de performance
        /// </summary>
        /// <param name="pl">Layer de s�ries de performance � cloner</param>
        public PerfLayer(PerfLayer pl)
        {
            this.dataBaseKey = pl.dataBaseKey;
            this.endRange = pl.endRange;
            this.endRangeType = pl.endRangeType;
            this.outputName = pl.outputName;
            this.outputUnitCode = pl.outputUnitCode;
            this.pointFactorName = pl.pointFactorName;
            this.pointFactorUnitCode = pl.pointFactorUnitCode;
            this.ranged = pl.ranged;
            this.serieFactorName = pl.serieFactorName;
            this.serieFactorUnitCode = pl.serieFactorUnitCode;
            this.startRange = pl.startRange;
            this.startRangeType = pl.startRangeType;
            for (int count = 0; count < pl.count; count++)
            {
                this.add(new PerfSerie(pl.perfSerieList.ElementAt(count)));
            }
        }



        /// <summary>
        /// Construit une Layer vide de toute Serie de points de performances
        /// </summary>
        /// <param name="ownFactorValue">Valeur du facteur associ� � la Layer (dimension 2)</param>
        /// <param name="pointFactorName">Nom de la dimension des Point de la Pile (dimension 1)</param>
        /// <param name="pointFactorUnitCode">Unit� de mesure de la dimension des points</param>
        /// <param name="serieFactorName">Nom de la dimension des Serie de la Pile (dimension 2)</param>
        /// <param name="serieFactorUnitCode">Unit� de mesure de la dimension des Serie</param>
        /// <param name="outName">Nom de la Layer (nom des r�sultat des pr�dictions r�alis�es avec cette Layer)</param>
        /// <param name="outUnitCode">Unit� de mesure de la pr�diction</param>
        public PerfLayer(double ownFactorValue,
                         String pointFactorName, int pointFactorUnitCode,
                         String serieFactorName, int serieFactorUnitCode,
                         String outName, int outUnitCode)
        {
            this.factorValue = ownFactorValue;
            this.pointFactorName = pointFactorName;
            this.pointFactorUnitCode = pointFactorUnitCode;
            this.serieFactorName = serieFactorName;
            this.serieFactorUnitCode = serieFactorUnitCode;
            this.outputName = outName;
            this.outputUnitCode = outUnitCode;
            this.perfSerieList = new List<PerfSerie>();
        }


        // SERVICES /////////////////////////////////////////////////////////////////////////////////////////


        /// <summary>
        /// Ajoute une Serie de performances � la Layer
        /// </summary>
        /// <param name="newPerfSerie">Nouvelle Serie � ajouter dans la Layer</param>
        /// <returns>True si l'ajout est r�ussi, False dans le cas contaire</returns>
        public bool add(PerfSerie newPerfSerie)
        {
            foreach (PerfSerie p in perfSerieList)
            {
                if (p.CompareTo(newPerfSerie) == 0)
                {
                    return false;
                }
            }
            // newPerfSerie est bien une nouvelle s�rie de layers de performance de vol
            perfSerieList.Add(newPerfSerie);
            perfSerieList.Sort();
            // TODO Lors de l'ajout de la premi�re Serie, on r�cup�re les infos de la dimension inf�rieure
            /// pointFactorName = newPerfSerie.getPrimaryDimension();
            /// pointFactorUnitCode = newPerfSerie.getPrimaryDimensionUnitCode();
            /// -->
            // Le domaine de calcul n'est plus valable
            ranged = false;
            return true;
        }


        /// <summary>
        /// Ajoute un Point de performances de vol � une Serie de la Layer
        /// Si la Serie n'existe pas, une Serie est cr��e pour accueillir le Point
        /// </summary>
        /// <param name="newPerfPoint">Nouveau Point de performances de vol</param>
        /// <param name="serieFactorValue">Facteur de la Serie dans laquelle inscrire le Point</param>
        /// <returns>True si l'ajout est r�ussi, False dans le cas contaire</returns>
        public bool add(PerfPoint newPerfPoint, double serieFactorValue)
        {

            bool foundIt = false;
            bool success = false;

            // Recherche de la Serie ayant un facteur identique
            for (int count = 0; count < perfSerieList.Count; count++)
            {
                if (serieFactorValue == SerieAt(count).factorValue)
                {
                    success = SerieAt(count).add(newPerfPoint);
                    foundIt = true;
                    break;
                }
            }
            // Pas de Serie qui convienne, on la cr�e
            if (!foundIt)
            {
                PerfSerie ps = new PerfSerie(serieFactorValue);
                success = ps.add(newPerfPoint);
                if (success)
                {
                    success = add(ps);
                }
            }
            return success;
        }




        /// <summary>
        /// Renvoie le nombre de Serie de performances s�lectionn�es dans la Layer
        /// </summary>
        /// <returns>Un entier repr�sentant le nombre de s�ries s�lectionn�es</returns>
        /// <remarks>TODO: Suppression du flag selected</remarks>
        public int selectedCount()
        {
            return 0;
            /*
            int selectedSeries = 0;

            foreach (PerfSerie ps in this.perfSerieList)
            {
                if (ps != null)
                    selectedSeries++;
            }
            return selectedSeries;
            */
        }




        /// <summary>
        /// Renvoie la Serie de performances ayant l'index fourni en argument
        /// </summary>
        /// <param name="index">Index de la Serie de performances souhait�e</param>
        /// <returns>La Serie de performances situ�e � la position index dans la Layer</returns>
        public PerfSerie SerieAt(int index)
        {
            return perfSerieList.ElementAt<PerfSerie>(index);
        }



        /*
        /// <summary>
        /// S�lectionne toutes les Serie de la Layer
        /// </summary>
        /// <remarks>TODO: Suppression du flag selected</remarks>
        public void selectAll()
        {
            foreach (PerfSerie ps in perfSerieList)
            {
                ;
            }
        }
        */



        /*
        /// <summary>
        /// D�s�lectionne toutes les Serie de la Layer
        /// </summary>
        /// <remarks>TODO: Suppression du flag selected</remarks>
        public void selectNone()
        {
            foreach (PerfSerie ps in perfSerieList)
            {
                ;
            }
        }
        */



        /// <summary>
        /// V�rifie si un valeur pass�e en argument est dans le range de la Layer
        /// </summary>
        /// <param name="x">Valeur � tester</param>
        /// <returns>True si la valeur est situ�e dans le range de la Layer, False dans le cas contraire
        /// </returns>
        public bool isInRange(double x)
        {
            if (x < startRange || (x == startRange && startRangeType == AeroCalc.MODEL_RANGE_EXCLUDE_LIMIT))
            {
                return false;
            }
            if (x > endRange || (x == endRange && endRangeType == AeroCalc.MODEL_RANGE_EXCLUDE_LIMIT))
            {
                return false;
            }
            return true;
        }


        /// <summary>
        /// Retourne une chaine de caract�re pr�sentant toutes les caract�ristiques de la Layer de performances
        /// </summary>
        /// <returns>String, descriptive de la Layer</returns>
        public override String ToString()
        {
            String msg = "";
            msg = "DB Key            : " + this.dataBaseKey + "\n";
            msg += "Output            : " + this.outputName + "\n";
            msg += "Output unit       :" + this.outputUnitCode + "\n";
            msg += "Point Factor Name : " + this.pointFactorName + "\n";
            msg += "Point Factor Unit :" + this.pointFactorUnitCode + "\n";
            msg += "Serie Factor Name : " + this.serieFactorName + "\n";
            msg += "Serie Factor Unit :" + this.serieFactorUnitCode + "\n";
            msg += "factor value : " + this.factorValue + "\n";
            msg += "Range : ";
            if (this.startRangeType == AeroCalc.MODEL_RANGE_EXCLUDE_LIMIT)
            {
                msg += "]";
            }
            else
            {
                msg += "[";
            }
            msg += this.startRange + ";" + this.endRange;
            if (this.endRangeType == AeroCalc.MODEL_RANGE_EXCLUDE_LIMIT)
            {
                msg += "[";
            }
            else
            {
                msg += "]";
            }
            /*
            msg += "\nSelected : ";
            if (selected)
            {
                msg += "YES";
            }
            else
            {
                msg += "NO";
            }
            */
            msg += "\nS�ries :\n";
            foreach (PerfSerie ps in perfSerieList)
            {
                msg += "Index = " + perfSerieList.IndexOf(ps) + "\n";
                msg += ps.ToString() + "\n";
            }
            return msg;
        }


        /// <summary>
        /// Calcule une pr�diction pour deux facteurs
        /// </summary>
        /// <param name="pointFactorValue">Facteur li� aux layers de performance</param>
        /// <param name="serieFactorValue">Facteur li� aux s�ries de layers de performance</param>
        /// <returns></returns>
        /// <remarks>TODO: Suppression de l'utilisation du flag selected</remarks>
        public double predict(double pointFactorValue, double serieFactorValue)
        {
            PerfSerie ps = new PerfSerie();
            double output = double.NaN;
            double serieOutput = double.NaN;

            if (this.count == 1)
            {
                if (serieFactorValue.Equals(double.NaN) || serieFactorValue == SerieAt(0).factorValue)
                {
                    // Cas 1: serieFactorValue est NaN, il n'y a pas de factorValue transmis pour ce calcul
                    // Cas 2: serieFactorValue est �gal au factorValue de l'unique s�rie
                    // Le calcul est r�alisable
                    output = SerieAt(0).predict(pointFactorValue);
                }
                else
                {
                    throw new ModelException(AeroCalc.E_SERIE_VALUE_OUT_OF_RANGE, this.outputName, "", serieFactorValue);
                }
            }

            // Si le domaine de calcul n'a pas �t� d�fini au pr�alable, il est r�duit � l'�tendue
            // de la Layer
            if (!ranged)
            {
                setRange();
            }
            // Test du domaine de calcul
            if (!isInRange(serieFactorValue))
            {
                throw new ModelException(AeroCalc.E_SERIE_VALUE_OUT_OF_RANGE,
                                           this.outputName, "", serieFactorValue);
            }


            // S�lection des s�ries
            //selectSubLayer(serieFactorValue, 3);
            // Calcul de la pr�diction pour chaque s�rie s�lectionn�e
            for (int count = 0; count < this.count; count++)
            {
                /*
                if (SerieAt(count).selected) {
                    serieOutput = SerieAt(count).predict(pointFactorValue);
                    ps.add(new PerfPoint(SerieAt(count).factorValue, serieOutput, false));
                }
                */
            }
            if (ps.count >= 1)
            {
                output = ps.predict(serieFactorValue);
            }







            try
            {
            }
            catch (ModelException e)
            {
                throw e;
            }
            return output;
        }


        /// <summary>
        /// D�finie le domaine de calcul de la s�rie
        /// </summary>
        /// <param name="start">Borne inf�rieure</param>
        /// <param name="startType">Type de borne</param>
        /// <param name="end">Borne sup�rieure</param>
        /// <param name="endType">Type de borne</param>
        /// <returns>True en cas de succ�s</returns>
        public bool setRange(double start, int startType, double end, int endType)
        {
            if (end < start)
            {
                return false;
            }
            startRange = start;
            endRange = end;
            if (startType == AeroCalc.MODEL_RANGE_EXCLUDE_LIMIT)
            {
                startRangeType = AeroCalc.MODEL_RANGE_EXCLUDE_LIMIT;
            }
            else
            {
                startRangeType = AeroCalc.MODEL_RANGE_INCLUDE_LIMIT;
            }
            if (endType == AeroCalc.MODEL_RANGE_EXCLUDE_LIMIT)
            {
                endRangeType = AeroCalc.MODEL_RANGE_EXCLUDE_LIMIT;
            }
            else
            {
                endRangeType = AeroCalc.MODEL_RANGE_INCLUDE_LIMIT;
            }
            ranged = true;
            return true;
        }


        /// <summary>
        /// D�finie le domaine de calcul de la s�rie
        /// </summary>
        /// <returns>True en cas de succ�s</returns>
        public bool setRange()
        {
            if (this.count > 0)
            {
                return setRange(SerieAt(0).factorValue, AeroCalc.MODEL_RANGE_INCLUDE_LIMIT,
                                SerieAt(perfSerieList.Count - 1).factorValue, AeroCalc.MODEL_RANGE_INCLUDE_LIMIT);
            }
            else
                return false;
        }


        // Interface(s) /////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// Compares the current PerfLayer instance with another PerfLayer and returns an integer that indicates their
        /// relative order based on the factor value.
        /// </summary>
        /// <param name="other">The PerfLayer instance to compare with the current instance.</param>
        /// <returns>A value less than zero if the current instance is less than <paramref name="other"/>; zero if they are
        /// equal; or a value greater than zero if the current instance is greater than <paramref name="other"/>.</returns>
        public int CompareTo(PerfLayer other)
        {
            if (this.factorValue < other.factorValue)
            {
                return -1;
            }
            if (this.factorValue > other.factorValue)
            {
                return 1;
            }
            return 0;
        }


        // Methods //////////////////////////////////////////////////////////////////////////////////////////


        /// <summary>
        /// Renvoie un tableau des indexes des Series de performance, class� par proximit� 
        /// de leur facteur avec une abscisse de r�f�rence
        /// </summary>
        /// <param name="x">Abscisse de r�f�rence</param>
        /// <returns>Tableau de Int, null si aucun point n'est pr�sent dans la s�rie</returns>
        private int[] sortedClosestSeries(double x)
        {

            int[] sortedIndexes;

            if (perfSerieList.Count < 1)
            {
                return null;
            }

            // Cas g�n�ral, la Layer contient des s�ries
            //
            sortedIndexes = new int[perfSerieList.Count];
            int minDistIndex = -1;
            int upIndex = -1;
            int downIndex = -1;
            double dist = -1;
            double minDist = Double.MaxValue;
            double[] distances = new double[perfSerieList.Count];
            int[] classement = new int[perfSerieList.Count];

            // Calcul des distances et d�termination du point de plus grande proximit�
            for (int count = 0; count < this.count; count++)
            {
                distances[count] = SerieAt(count).factorValue - x;
                dist = Math.Abs(distances[count]);
                classement[count] = -1;
                if (dist < minDist)
                {
                    // La distance associ�e au point en cours est la plus petite rencontr�e jusqu'� pr�sent
                    minDist = dist;
                    minDistIndex = count;
                }
            }
            // Enregistrement du point de plus grande proximit�
            sortedIndexes[0] = minDistIndex;

            // Cas des extr�mit�s
            if (minDistIndex == 0)
            {
                // Trivial, le classement est identique � l'index de tableau
                for (int count = 0; count < sortedIndexes.Length; count++)
                {
                    sortedIndexes[count] = count;
                }
                return sortedIndexes;
            }
            if (minDistIndex == perfSerieList.Count - 1)
            {
                // Trivial, le classement est inverse de l'index du tableau
                for (int count = 0; count < sortedIndexes.Length; count++)
                {
                    classement[count] = sortedIndexes.Length - 1 - count;
                }
                return sortedIndexes;
            }

            // Cas g�n�ral, minDistIndex n'est pas en limite de tableau
            downIndex = minDistIndex - 1;
            upIndex = minDistIndex + 1;

            for (int count = 1; count < sortedIndexes.Length; count++)
            {
                if (downIndex < 0)
                {
                    // upIndex d�signe le dernier point disponible vers la limite basse
                    sortedIndexes[count] = upIndex;
                    upIndex++;
                }
                else if (upIndex > distances.Length - 1)
                {
                    // downIndex d�signe le seul point disponible
                    sortedIndexes[count] = downIndex;
                    downIndex--;
                }
                else
                {
                    if (Math.Abs(distances[downIndex]) > Math.Abs(distances[upIndex]))
                    {
                        // upIndex d�signe le point le plus proche
                        sortedIndexes[count] = upIndex;
                        upIndex++;
                    }
                    else
                    {
                        // downIndex d�signe le point le plus proche
                        sortedIndexes[count] = downIndex;
                        downIndex--;
                    }
                }
            }
            return sortedIndexes;
        }
        // Accesseur de test
        public int[] _A_SortedClosestSeries(double x)
        {
            return sortedClosestSeries(x);
        }



        /*
        /// <summary>
        /// S�lectionne un nombre nb de s�ries li�es de fa�on continue autour d'une valeur de facteur x
        /// </summary>
        /// <param name="x">Abscisse de r�f�rence</param>
        /// <param name="nb">Nombre de layers � s�lectionner</param>
        /// <remarks>TODO: Suppression du flag selected</remarks>
        private bool selectSubLayer(double x, int nb)
        {

            int[] series = sortedClosestSeries(x);
            //selectNone();

            if (series == null)
            {
                return false;
            }
            if (nb == 0)
            {
                return true;
            }
            if (series.Length == 1 || nb == 1)
            {
                //SerieAt(series[0]).selected = true;
                return true;
            }
            if (series.Length == 2 || nb == 2)
            {
                //SerieAt(series[0]).selected = true;
                //SerieAt(series[1]).selected = true;
                return true;
            }
            else
            {
                // Trois s�ries minimum dans la layer, il faut maintenant consid�rer les breakpoints
                int count = 0;
                int selectCounter = 0;
                int upBreakSerie = series.Length;
                int dnBreakSerie = -1;

                while (selectCounter < nb && count < series.Length)
                {
                    if (series[count] < dnBreakSerie || series[count] > upBreakSerie)
                    {
                        // Le point ne peut pas �tre s�lectionn�, on passe au suivant

                    }
                    else
                    {
                        // S�lection de la s�rie
                        //SerieAt(series[count]).selected = true;
                        selectCounter++;
                        if (SerieAt(series[count]).isBreak)
                        {
                            if (SerieAt(series[count]).factorValue < x)
                            {
                                dnBreakSerie = series[count];
                            }
                            else
                            {
                                upBreakSerie = series[count];
                            }
                        }
                    }
                    count++;
                }
                return true;
            }
        }
        // Accesseur pour la classe de test unitaire
        public bool _A_SelectSubLayer(double x, int nb)
        {
            return selectSubLayer(x, nb);
        }
        */

    }

}