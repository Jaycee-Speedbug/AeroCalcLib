using System;
using System.Collections.Generic;
using System.Linq;


namespace AeroCalcCore
{


    /// <summary>
    /// Classe d�finissant le container des mod�les de performances
    /// Fourni l'acc�s � ces mod�les et les outils permettant de charger en m�moire ces mod�les depuis
    /// des fichiers ou des connexions � des bases de donn�es
    /// </summary>
    /// <remarks>
    /// Am�liorations possibles:
    /// - Utiliser une classe encapsulant les objets de type PerfPile
    /// - Ajouter l'interface IEquatable aux objets PerfPile (ou leur capsule) pour assurer
    /// de meilleures performances de recherche
    /// </remarks>
    public class DataModelContainer
    {

        /*
         * Propri�t�s
         */

        public Units UnitsLib { get; private set; }


        /*
         * Membres
         */

        List<PerfPile> dataModels;
        //ConnectorUnitCSVFile unitsConnector;
        XMLFile xmlConnector;
        ModelCSVFile csvConnector;



        /*
         * Constructeurs
         */

        /// <summary>
        /// Construit un objet DataModelContainer, Container des mod�les de performances de vol
        /// </summary>
        /// 
        public DataModelContainer()
        {
            dataModels = new List<PerfPile>();
            xmlConnector = new XMLFile();
            csvConnector = new ModelCSVFile();
        }



        /*
         * Services
         */

        /// <summary>
        /// Fixe le r�pertoire contenant les mod�les de performances � charger.
        /// Retourne True en cas de succ�s, False dans le cas contraire.
        /// </summary>
        /// <param name="directoryPath">Chemin du r�pertoire</param>
        /// <returns>
        /// 
        /// </returns>
        public bool setDataModelsDirectory(string directoryPath)
        {
            return (csvConnector.setWorkDirectory(directoryPath) & xmlConnector.setWorkDirectory(directoryPath));
        }



        /// <summary>
        /// Retourne un tableau de string contenant les r�pertoires des diff�rents Connectors du Container
        /// </summary>
        /// <returns></returns>
        public string[] getDataModelsDirectory()
        {
            string[] directories = new string[2];
            directories[0] = this.csvConnector.directoryAbsolutePath;
            directories[1] = this.xmlConnector.directoryAbsolutePath;
            return directories;
        }



        public void setUnitsLibrary(Units UnitsLibrary)
        {
            UnitsLib = UnitsLibrary;
        }



        /// <summary>
        /// Retourne un mod�le de performances de vol � la position index dans le container
        /// </summary>
        /// <param name="index">Index de position de ce mod�le de performances dans le container</param>
        /// <returns>PerfPile contenant le mod�le de performances</returns>
        /// 
        public PerfPile dataModelByIndex(int index)
        {
            return dataModels.ElementAt(index);
        }



        /*
        /// <summary>
        /// Retourne le dictionnaire des unit�s
        /// </summary>
        /// <returns>UnitDictionnary, le dictionnaire des unit�s</returns>
        /// 
        public UnitDictionary unitDictionary() {
            return dataUnits;
        }
        */



        /// <summary>
        /// Retourne le r�sultat d'un calcul multi-dimensionnel
        /// </summary>
        /// <param name="dataModelName">Nom du mod�le � utiliser</param>
        /// <param name="factors">Liste des facteurs pass�s en argument</param>
        /// <returns>
        /// double, r�sultat du calcul
        /// </returns>
        /// <remarks>
        /// Fontion r�cursive
        /// </remarks>
        public double compute(string dataModelName, List<CommandFactor> factors)
        {

            // Recherche du mod�le de performances permettant le traitement (nom + discret)
            //PerfPile Pile = dataModels.ElementAt(dataModelIndex(dataModelName, factors));
            PerfPile Pile = dataModels.Find(x => x.outputName == dataModelName);
            double result = double.NaN;

            //int commandIndex = container.dataModelIndex(Cmd.subs[0], Cmd.Factors);
            if (Pile == null)
            {
                // Aucun mod�le ne r�pond aux crit�res de s�lection
                return double.NaN;
            }


            // Recherche de la valeur des diff�rents facteurs n�cessaires aux calculs
            if (Pile != null)
            {
                // Le mod�le est identifi�
                //pp = container.dataModelByIndex(commandIndex);
                // Analyse des facteurs, param�tres et options de la commande

                //double pointFactorValue = factors.Find(x => x.name.Equals(Pile.pointFactorName)).value;
                double pointFactorValue = valueFromFactor(factors, Pile.pointFactorName);
                if (double.IsNaN(pointFactorValue))
                {
                    // serieFactorValue n'est pas disponible dans les facteurs, on tente de le calculer
                    pointFactorValue = compute(Pile.pointFactorName, factors);
                    if (double.IsNaN(pointFactorValue))
                    {
                        // Echec de la tentative du calcul
                        return double.NaN;
                    }
                }

                //double serieFactorValue = factors.Find(x => x.name.Equals(Pile.serieFactorName)).value;
                double serieFactorValue = valueFromFactor(factors, Pile.serieFactorName);
                if (double.IsNaN(serieFactorValue))
                {
                    // serieFactorValue n'est pas disponible dans les facteurs, on tente de le calculer
                    serieFactorValue = compute(Pile.serieFactorName, factors);
                    if (double.IsNaN(serieFactorValue))
                    {
                        // Echec de la tentative du calcul
                        return double.NaN;
                    }
                }

                //double layerFactorValue = factors.Find(x => x.name.Equals(Pile.layerFactorName)).value;
                double layerFactorValue = valueFromFactor(factors, Pile.layerFactorName);
                if (double.IsNaN(layerFactorValue))
                {
                    // layerFactorValue n'est pas disponible dans les facteurs, on tente de le calculer
                    serieFactorValue = compute(Pile.layerFactorName, factors);
                    if (double.IsNaN(layerFactorValue))
                    {
                        // Echec de la tentative du calcul
                        return double.NaN;
                    }
                }

                try
                {
                    result = Pile.predict(pointFactorValue, serieFactorValue, layerFactorValue);
                }
                catch (ModelException e)
                {
                    // On r�cup�re d'une exception ou un param�tre est hors du range ou il peut �tre utilis�
                    // TODO les infos de l'exception sont g�n�r�es directement dans predict()
                    throw e;
                }
            }
            return result;
        }



        /// <summary>
        /// Renvoie l'index (clef) du mod�le de performances de vol, identifi� par le nom
        /// fournis en argument.
        /// Renvoie -1 si aucune correspondance, une valeur inf�rieure � -1 si plusieurs correspondances trouv�es
        /// </summary>
        /// <param name="dataModelName">Nom du mod�le de performances</param>
        /// <returns>L'index de la fonction de calcul de performances</returns>
        /// 
        public int dataModelIndex(string dataModelName)
        {
            int foundIndex = -1;
            for (int count = 0; count < this.dataModels.Count; count++)
            {
                if (dataModelName.Equals(dataModels.ElementAt(count).outputName))
                {
                    if (foundIndex > -1)
                    {
                        // Une autre occurence a d�j� �t� d�couverte !
                        foundIndex = -2;
                    }
                    else if (foundIndex == -1)
                    {
                        // Premi�re occurence !
                        foundIndex = count;
                    }
                    else
                    {
                        // D�j� plusieurs occurences
                    }
                    foundIndex--;
                }
            }
            return foundIndex;
        }



        /// <summary>
        /// Renvoie l'index (clef) du premier mod�le de performances de vol, identifi� par son nom et le nom
        /// du discret fournis en argument.
        /// Retourne -1 si aucune correspondance n'est trouv�e, un entier inf�rieur � -1 si plusieurs occurences
        /// sont trouv�es.
        /// </summary>
        /// <param name="dataModelName">Nom du mod�le de performances</param>
        /// <param name="discretName">Nom du param�tre discret associ� au mod�le</param>
        /// <returns>L'index de la fonction de calcul de performance</returns>
        /// 
        public int dataModelIndex(string dataModelName, string discretName)
        {
            int foundIndex = -1;
            if (discretName.Equals(""))
            {
                // Pas de nom de param�tre discret, on ne consid�re que le nom du mod�le
                return dataModelIndex(dataModelName);
            }
            else
            {
                // Un nom de param�tre discret est fourni, on en tient compte dans la recherche
            }
            for (int count = 0; count < this.dataModels.Count; count++)
            {
                if (dataModelName.Equals(dataModels.ElementAt(count).outputName) &&
                    discretName.Equals(dataModels.ElementAt(count).discretName))
                {
                    if (foundIndex > -1)
                    {
                        // Une autre occurence a d�j� �t� d�couverte !
                        foundIndex = -2;
                    }
                    else if (foundIndex == -1)
                    {
                        // Premi�re occurence !
                        foundIndex = count;
                    }
                    else
                    {
                        // D�j� plusieurs occurence
                    }
                    foundIndex--;
                }
            }
            return foundIndex;
        }



        /// <summary>
        /// Renvoie l'index (clef) du premier mod�le de performances de vol, identifi� par le nom, le discret
        /// et sa valeur fournis en argument.
        /// Retourne -1 si aucune correspondance n'est trouv�e, un entier inf�rieur � -1 si plusieurs occurences
        /// sont trouv�es.
        /// </summary>
        /// <param name="dataModelName">Nom du mod�le de performances</param>
        /// <param name="discretName">Nom du param�tre discret associ� au mod�le</param>
        /// <param name="discretValue">Valeur discr�te associ�e au mod�le</param>
        /// <returns>L'index de la fonction de calcul de performance</returns>
        /// 
        public int dataModelIndex(string dataModelName, string discretName, long discretValue)
        {
            int foundIndex = -1;
            if (discretName.Equals(""))
            {
                // Pas de nom de param�tre discret, on ne consid�re que le nom du mod�le
                return dataModelIndex(dataModelName);
            }
            else
            {
                // Un nom de param�tre discret est fourni, on en tient compte dans la recherche
            }
            for (int count = 0; count < this.dataModels.Count; count++)
            {
                if (dataModelName.Equals(dataModels.ElementAt(count).outputName) &&
                    discretName.Equals(dataModels.ElementAt(count).discretName) &&
                    discretValue == dataModels.ElementAt(count).discretValue)
                {
                    if (foundIndex > -1)
                    {
                        // Une autre occurence a d�j� �t� d�couverte !
                        foundIndex = -2;
                    }
                    else if (foundIndex == -1)
                    {
                        // Premi�re occurence !
                        foundIndex = count;
                    }
                    else
                    {
                        // D�j� plusieurs occurence
                    }
                    foundIndex--;
                }
            }
            return foundIndex;
        }



        /// <summary>
        /// Renvoie l'index (clef) du premier mod�le de performances de vol, identifi� par le nom, le discret 
        /// et sa valeur fournis en argument, dans tableau de facteurs.
        /// Retourne -1 si aucune correspondance n'est trouv�e, un entier inf�rieur � -1 si plusieurs occurences
        /// sont trouv�es.
        /// </summary>
        /// <param name="dataModelName">Nom du mod�le de performances</param>
        /// <param name="Factors">Tableau des facteurs pass�s en argument, dont un peut �tre le discret</param>
        /// <returns>L'index de la fonction de calcul de performances</returns>
        /// 
        public int dataModelIndex(string dataModelName, List<CommandFactor> Factors)
        {
            int foundIndex = -1;

            // Examen de tous les mod�les de donn�es contenus dans le container
            for (int count = 0; count < this.dataModels.Count; count++)
            {
                if (dataModelName.Equals(dataModels.ElementAt(count).outputName))
                {
                    // Le nom du mod�le a �t� trouv�
                    foreach (CommandFactor factor in Factors)
                    {
                        // Recherche, pour chaque facteur, le nom du discret et sa valeur dans les caract�ristiques
                        if (factor.name.Equals(dataModels.ElementAt(count).discretName) &&
                            factor.value == (double)dataModels.ElementAt(count).discretValue)
                        {
                            // Le nom du mod�le, le nom du discret et la valeur du discret matchent !
                            if (foundIndex > -1)
                            {
                                // Une autre occurence a d�j� �t� d�couverte !
                                foundIndex = -2;
                            }
                            else if (foundIndex == -1)
                            {
                                // Premi�re occurence !
                                foundIndex = count;
                            }
                            else
                            {
                                // D�j� plusieurs occurence
                                foundIndex--;
                            }
                        }
                    }
                }
            }
            return foundIndex;
        }



        /// <summary>
        /// Renvoie un tableau des index des mod�les de performances de vol contenus dans le container,
        /// dont le nom match le filtre pass� en argument
        /// </summary>
        /// <param name="fileNameFilter">Chaine de caract�re utilis�e comme filtre</param>
        /// <returns>Tableau contenant les indexes des fonctions</returns>
        /// <remarks>
        /// Le d�limiteur standard des noms de fonction est le point
        /// Le caract�re * peut �tre utilis� comme carte blanche
        /// </remarks>
        /// 
        public List<int> dataModelIndexes(string fileNameFilter)
        {

            string[] functionNameSubs;
            string[] filterSubs;
            string[] originalFilterSubs;
            bool match;
            List<int> perfFunctionIndexes = new List<int>();

            char[] splitters = { AeroCalcCommand.CMD_OPERATOR_SPLITTER };
            // D�coupe du nom du filtre
            originalFilterSubs = fileNameFilter.Split(splitters, StringSplitOptions.None);

            // Analyse de chaque outputName
            foreach (PerfPile pp in dataModels)
            {

                // D�coupe du nom de fonction et du filtre
                functionNameSubs = pp.outputName.Split(splitters, StringSplitOptions.None);
                // Reset des mots du filtre
                filterSubs = originalFilterSubs;

                if (originalFilterSubs.Length > functionNameSubs.Length)
                {
                    // Plus de mots dans le filtre que dans le nom de la fonction, �a ne peut pas matcher
                    continue;
                }

                if (originalFilterSubs.Length < functionNameSubs.Length)
                {
                    if (fileNameFilter.Contains(AeroCalcCommand.CMD_WORD_WHITE_CARD))
                    {
                        // Le filtre comporte moins de mots que le nom de la fonction, mais au moins une WHITE_CARD
                        // Modification des mots du filtre gr�ce � la WHITE_CARD
                        filterSubs = expendFilter(originalFilterSubs, functionNameSubs.Length);
                        // TODO Et si expendFilter renvoyait un null ??
                    }
                    else
                    {
                        // Ca ne peut pas matcher, on passe � la suite
                        continue;
                    }
                }
                // filterSubs comporte maintenant le m�me nombre de mots que le nom de la fonction
                match = false;
                for (int index = 0; index < functionNameSubs.Length; index++)
                {
                    if (filterSubs[index].Contains(AeroCalcCommand.CMD_WORD_WHITE_CARD) ||
                        filterSubs[index].Equals(functionNameSubs[index], StringComparison.InvariantCultureIgnoreCase))
                    {
                        // Ca match !
                        match = true;
                    }
                    else
                    {
                        // Ce mot ne match pas, pas la peine d'aller plus loin
                        match = false;
                        break;
                    }
                }
                if (match == true)
                {
                    // Le nom de cette fonction match le filtre
                    perfFunctionIndexes.Add(dataModels.IndexOf(pp));
                }
            }
            return perfFunctionIndexes;
        }



        /// <summary>
        /// Renvoie un tableau des index des mod�les de performances de vol contenus dans le container,
        /// dont le nom match le filtre pass� en argument
        /// </summary>
        /// <param name="fileNameFilter">Chaine de caract�re utilis�e comme filtre</param>
        /// <param name="Factors">Tableau des facteurs pass�s en argument, dont un peut �tre le discret</param>
        /// <returns>Tableau contenant les indexes des fonctions</returns>
        /// <remarks>
        /// Surcharge sur la base de List<int> dataModelIndexes(string fileNameFilter)
        /// </remarks>
        /// 
        public List<int> dataModelIndexes(string fileNameFilter, List<CommandFactor> Factors)
        {

            List<int> newIndexes = new List<int>();
            foreach (int index in dataModelIndexes(fileNameFilter))
            {
                foreach (CommandFactor factor in Factors)
                {
                    // Recherche, pour chaque facteur, le nom du discret et sa valeur dans les caract�ristiques
                    if (factor.name.Equals(dataModels.ElementAt(index).discretName) &&
                        factor.value == (double)dataModels.ElementAt(index).discretValue)
                    {
                        // Le nom du discret et la valeur du discret matchent !
                        newIndexes.Add(index);
                        break;
                    }
                }
            }
            return newIndexes;
        }



        /// <summary>
        /// Charge les mod�les de performances de vol en appliquant le filtre pass� en argument et retourne
        /// le nombre de mod�les charg�s.
        /// </summary>
        /// <param name="directoryPath"></param>
        /// <param name="dataModelNameFilter">Filtre des noms de mod�les de performances � s�lectionner</param>
        /// <returns>int, nombre de mod�les charg�s</returns>
        /// TODO Utiliser EnvironmentContext pourr le path du directory
        public int loadDataModels(string directoryPath, string dataModelNameFilter)
        {

            PerfPile pp;
            int counter = 0;

            // Recherche des fichiers � analyser dans le dossier des mod�les (par d�faut {App}/data )
            foreach (string fileName in csvConnector.filesInDirectory(directoryPath, string.Concat(dataModelNameFilter, ".csv")))
            {
                pp = csvConnector.readFile(fileName);
                if (pp != null)
                {
                    if (dataModelIndex(pp.outputName) < 0)
                    {
                        // Ce mod�le n'est pas d�j� enregistr�, on peut l'ajouter � la liste
                        dataModels.Add(pp);
                        if (!pp.hidden)
                        {
                            counter++;
                        }
                    }
                }
            }
            return counter;
        }



        /// <summary>
        /// Renvoie, pour affichage, les signatures de tous les mod�les de performances
        /// enregistr� dans le container
        /// </summary>
        /// <returns>
        /// signatures au format texte du mod�le FUNCTION_NAME PARAM1 PARAM2 ...
        /// </returns>
        /// <remarks>
        /// TODO counter est un int, attention au d�passement de capacit� en production
        /// </remarks>
        /// 
        public string dataModelSignatures()
        {
            string msg = "";
            int counter = 0;

            foreach (PerfPile pp in this.dataModels)
            {
                if (!pp.hidden)
                {
                    msg += modelSignature(pp.outputName) + Environment.NewLine;
                    counter++;
                }
            }
            return msg;
        }



        /// <summary>
        /// Retourne une string contenant toutes les Pile en m�moire
        /// </summary>
        /// <returns>
        /// </returns>
        public override string ToString()
        {

            string msg = "";

            foreach (PerfPile pp in dataModels)
            {
                msg += pp.ToString();
            }
            return msg;
        }



        /*
         * METHODES
         */

        /// <summary>
        /// Retourne une string contenant la signature du mod�le de calcul
        /// </summary>
        /// <param name="outputName"></param>
        /// <returns>
        /// </returns>
        private string modelSignature(string outputName)
        {
            // Recherche du nom du mod�le dans la liste dataModels
            PerfPile p = this.dataModels.Find(x => x.outputName.Equals(outputName));
            if (p != null)
            {
                List<String> factorList = new List<string>();
                string factors = "";
                foreach (string word in factorsSignature(outputName).Split(AeroCalcCommand.CMD_SEPARATOR))
                {
                    if (!string.IsNullOrEmpty(word) && factorList.Find(x => x.Equals(word)) == null)
                    {
                        // On ajoute que les noms distincts des diff�rents facteurs 
                        factorList.Add(word);
                    }
                }
                foreach (string word in factorList)
                {
                    factors += word + " ";
                }
                return p.outputName + " " + factors;
            }
            else
            {
                // Aucun mod�le de donn�e ne correspond � ce nom
                return "";
            }
            // Suppression des doublons dans les facteurs

        }


        /// <summary>
        /// Retourne une string contenant les noms des facteurs d'un mod�le de calcul
        /// </summary>
        /// <param name="outputName">Nom du mod�le de calcul</param>
        /// <returns>
        /// </returns>
        private string factorsSignature(string outputName)
        {
            PerfPile p = this.dataModels.Find(x => x.outputName == outputName);
            string signature;

            if (p != null)
            {
                // Le mod�le existe
                signature = factorsSignature(p.discretName) + " ";
                signature += factorsSignature(p.layerFactorName) + " ";
                signature += factorsSignature(p.serieFactorName) + " ";
                signature += factorsSignature(p.pointFactorName) + " ";
                return signature;
            }
            else
            {
                return outputName;
            }
        }


        /// <summary>
        /// Retourne la valeur num�rique contenue dans un facteur dont le nom est donn� en argument.
        /// Renvoie NaN si aucun facteur n'est reconnu dans la liste fournie
        /// Renvoie 1 si le nom est une chaine vide (absence de facteur veut dire facteur = 1)
        /// </summary>
        /// <param name="list">Liste des commandFactor</param>
        /// <param name="name">Nom du facteur</param>
        /// <returns></returns>
        private double valueFromFactor(List<CommandFactor> list, string name)
        {
            if (name.Equals("")) { return 1; }
            foreach (CommandFactor factor in list)
            {
                if (factor.name.Equals(name))
                {
                    return factor.value;
                }
            }
            return double.NaN;
        }


        /// <summary>
        /// Transforme un filtre de nom de fonction pour comporter le nombre de mots pass� en argument
        /// Permet l'utilisation des caract�res WHITE_CARD dans les filtres
        /// Plusieures WHITE_CARD autoris�es
        /// 
        /// </summary>
        /// <param name="filterSubs">Table de mots composant le filtre</param>
        /// <param name="wordCount">Nombre de mots que doit comporter le filtre</param>
        /// <returns>
        /// Une nouvelle table de mots composant le nouveau filtre
        /// </returns>
        /// <remarks>
        /// Format support�:
        /// *.WORD
        /// WORD.*
        /// WORD.*.WORD
        /// 
        /// TODO Refactoring:
        /// Utiliser les List<string> 
        /// </remarks>
        private string[] expendFilter(string[] filterSubs, int wordCount)
        {

            int index = -1;
            bool expended = false;
            string[] expendedFilterSubs = new string[wordCount];

            // Recherche de la position de la WHITE_CARDS
            for (int count = 0; count < filterSubs.Length; count++)
            {
                if (filterSubs[count].Contains(AeroCalcCommand.CMD_WORD_WHITE_CARD) && index == -1)
                {
                    // Premi�re occurence de la WHITE_CARD
                    index = count;
                    break;
                }
            }
            // Expension du filtre
            if (index >= 0 && index <= wordCount - 1)
            {
                // La position de la premi�re WHITE_CARD est rep�r�e
                int filterSubsCount = 0;
                int count = 0;
                while (count < wordCount)
                {
                    // Recopie en commen�ant par le d�but, et compl�ment des mots manquants par une/des WHITE_CARD
                    if (filterSubs[filterSubsCount].Contains(AeroCalcCommand.CMD_WORD_WHITE_CARD))
                    {
                        // Insertion(s) de WHITE_CARD
                        for (int lcount = 0; lcount <= wordCount - filterSubs.Count(); lcount++)
                        {
                            expendedFilterSubs[count] = string.Concat(AeroCalcCommand.CMD_WORD_WHITE_CARD);
                            count++;
                            // L'expension a �t� r�alis�e, elle n'est autoris�e qu'une seule fois
                            // � la premi�re occurence de white card
                            if (expended) { break; }
                        }
                        expended = true;
                    }
                    else
                    {
                        expendedFilterSubs[count] = filterSubs[filterSubsCount];
                        count++;
                    }
                    filterSubsCount++;
                }
            }
            else
            {
                // La position de la WHITE_CARD n'a pas �t� trouv�e
                return null;
            }
            return expendedFilterSubs;
        }
        // Accesseurs de tests unitaires
        public string[] _A_expendFilter(string[] filterSubs, int wordCount)
        {
            return expendFilter(filterSubs, wordCount);
        }

    }

}